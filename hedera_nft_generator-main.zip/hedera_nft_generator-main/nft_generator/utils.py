def createBaseDict():
    return {
        1: 'Red',
        2: 'Blue',
        3: 'Yellow',
        4: 'Green',
        5: 'Red',
        6: 'Blue',
        7: 'Yellow',
        8: 'Green',
        9: 'Red',
        10: 'Golden',
    }

def createBodyDict():
    return {
        1: 'Tone 1',
        2: 'Tone 2',
        3: 'Tone 3',
        4: 'Tone 4',
        5: 'Tone 1',
        6: 'Tone 2',
        7: 'Tone 3',
        8: 'Tone 4',
        9: 'Tone 4',
        10: 'Ghost',
    }

def createHairDict():
    return {
        1: 'Tone 1',
        2: 'Tone 2',
        3: 'Tone 3',
        4: 'Tone 4',
        5: 'Tone 1',
        6: 'Tone 2',
        7: 'Tone 3',
        8: 'Tone 4',
        9: 'Tone 4',
        10: 'Bald',
    }

def createPantsDict():
    return {
        
        1: 'Purple',
        2: 'Blue',
        3: 'Black',
        4: 'Dungeries',
        5: 'Purple',
        6: 'Blue',
        7: 'Black',
        8: 'Dungeries',
        9: 'Dungeries',
        10: 'No Pants',
    }

def createTopDict():
    return {
        
        1: 'Red',
        2: 'Blue',
        3: 'Yellow',
        4: 'Cheque',
        5: 'Red',
        6: 'Blue',
        7: 'Yellow',
        8: 'Cheque',
        9: 'Cheque',
        10: 'Topless',
    }

def createPropDict():
    return {
        
        1: 'Did coding ballon',
        2: 'None',
        3: 'None',
        4: 'None',
        5: 'None',
        6: 'None',
        7: 'Dark purple balloon',
        8: 'None',
        9: 'None',
        10: 'None',
    }

def createBlingDict():
    return {
        
        1: 'Bracelet',
        2: 'None',
        3: 'None',
        4: 'Chain',
        5: 'None',
        6: 'None',
        7: 'None',
        8: 'None',
        9: 'None',
        10: 'None',
    }

def createTattooDict():
    return {
        
        1: 'None',
        2: 'None',
        3: 'Arm tattoo',
        4: 'None',
        5: 'None',
        6: 'None',
        7: 'Arm tattoo',
        8: 'None',
        9: 'None',
        10: 'None',
    }

def createShadesDict():
    return {
        
        1: 'None',
        2: 'None',
        3: 'Black shades',
        4: 'None',
        5: 'None',
        6: 'None',
        7: 'None',
        8: 'None',
        9: 'None',
        10: 'None',
    }

def createCoinDict():
    return {
        
        1: 'None',
        2: 'None',
        3: 'None',
        4: 'None',
        5: 'None',
        6: 'None',
        7: 'Gold HBAR coin',
        8: 'None',
        9: 'None',
        10: 'None',
    }
